#include <stdio.h>
#include <string.h>

#include "info.h"

int main ( int argc, char **argv )
{
	if ( strcmp(argv[1], "--version") == 0 )
	{
		printf("%s version %s.\n", PROGRAM_NAME, PROGRAM_VERSION);
		return 0;
	}

	int i;
	for ( i = 1; i < argc; i++ )
		printf("%s ", argv[i]);

	putchar('\n');

	return 0;
}
