#! /usr/bin/env python

import os

os.system("printer Hello World!")
